<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout1.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
?>
<div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
    <p><b><font size="+1"><strong>Book Classified & Display Advertisements for Indian Newspapers Instantly!</strong></font></b></p><p></p>
    <p align="justify"> Company Name is the easiest way to book Classified & Display Advertisements for Times of India, Hindustan Times, 
    Hindu, Mid-Day, ABP & all other leading newspaper publications! Now book Matrimonial, Property, Recruitment Newspaper Ads at lowest rates. </p>
      <div class="clear"></div>
    </div>

  <!-- ####################################################################################################### -->
      <div class="clear"></div>
      <p></p>
  <h2 align="center">Rates</h2>
        <table summary="Summary Here" cellpadding="0" cellspacing="0" align="center">
          <thead>
            <tr>
              <th>Paper</th>
              <th>City</th>
              <th>State</th>
              <th>Rate </th>
              <th>Discount </th>
              <?php
			  $sql = "select distinct p.papername,c.city_name,s.state_name,r.rate_amount,d.per from tbl_paper p ,tbl_rate r,tbl_state s,tbl_city c,tbl_discount d where d.d_id = r.d_id and c.city_id = r.city_id and c.city_id = s.state_id";
			  $result = mysql_query($sql);
			  while($r = mysql_fetch_array($result))
			  {
				  echo " <tbody><tr><td>$r[0]</td><td>$r[1]</td><td>$r[2]</td><td>$r[3]</td><td>$r[4]</td></tr></tbody>";
			  }
			  ?>
           
         
            </tr>
          </tbody>
        </table>
    
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
  
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>