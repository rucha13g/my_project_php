<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Realistic</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script language="javascript" type="text/javascript">
function validEmail(email)
{
    var email = document.getElementById("unm").value; 
    var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
    if (reg.test(email))
    {
        return true;
    }
    else{
        alert('Enter proper Email id');
    }
}



</script>
</head>
<body>
<?php
include("connection.php");
$count = 0;
  	
if(isset($_POST['submit']))
{
    if($_POST['submit'] == 0)
    {
	$unm = trim($_POST['unm']);
	$pd = trim($_POST['pd']);
	
//for validation...1
     if(($unm == " ") && ($pd == " "))
     {
    	 echo "<script language='javascript'> alert('fill details');</script>";
     }
     else
     { 	 
	  	 $sql = "select * from tbl_login where username = '$unm' and password = '$pd' and isdeleted = 0";
    	 $result = mysql_query($sql);
         $count = mysql_num_rows($result);           	 
    	 if($count >= 1)
          	 {
			 while($row = mysql_fetch_array($result))
			 {
				 $type = $row[3];
			 }
			 if($type == "user")
			{
			session_start(); 
			
            $_SESSION['user'] = $unm;
			
    		echo "<script language = 'javascript'> window.location.href='user_home.php';</script>";
			}
			
   		 }
		 
 	 }

 	 }
	if($_POST['submit'] == 1)
 {
 
	$pd = trim($_POST['pd']);
    $unm = trim($_POST['unm']);
    $sql1 = "select * from tbl_login where username = '$unm' and isdeleted = 0";
    $result1 = mysql_query($sql1) or die(mysql_error());				
		while( $row1 = mysql_fetch_array($result1))		
		{
		
		 function genpwd($cnt)  
				{  
				// characters to be included for randomization, here you can add or delete the characters   
				   			  
				 $pwd = str_shuffle('abcefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@#%$*');  
				  
				// here specify the 2nd parameter as start position, it can be anything, default 0   
				  				  
				 return substr($pwd,0,$cnt);   
				}
				$password = genpwd(8);
	             $to = $_POST['unm'];
               // $subject = $_POST['subtxt'];
                //$msg = $_POST['msgtxt'];
            	include ("class.phpmailer.php"); // include the class name
				$mail = new PHPMailer(); // create a new object
				$mail->IsSMTP(); // enable SMTP
				$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
				$mail->SMTPAuth = true; // authentication enabled
				$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for GMail
				//$mail->Host = "208.91.199.120";
                $mail->Host = "plus.smtp.mail.yahoo.com";
				$mail->Port = 465; // or 587
				$mail->IsHTML(true);
				$mail->Username = "desire_infotech@yahoo.com";
				$mail->Password = "India@123";
				$mail->SetFrom("desire_infotech@yahoo.com");
				//$mail->Subject = $subject;
				$mail->Body = $password;
				$mail->AddAddress($to);
                if(!$mail->Send()){
					
					
					echo "<script language='javascript'>alert('" . $mail->ErrorInfo . "');</script>";
				}
				else{
					echo "<script language='javascript'>alert('Password has been sent');</script>";
				}
				$sql4 = "update tbl_login set password = '$password' where username = '$unm'";
		$result4 = mysql_query($sql4);
		
		$sql5 = "update tbl_user set password = '$password' where emailid = '$unm'";
		$result5 = mysql_query($sql5);
}
 }

}
?>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
?>
  <div class="container">

 <div id="respond">
<form method="post">
<table align="center">
<tr>
<td>Email Id </td>
<td><input type="text" id="unm" name="unm" /></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" id="pd" name="pd" /></td>
</tr>
</table>
<table align="center">
<tr>
<td ><button type="submit" id="submit" name="submit" value="0" /> <font color="#663333">Log In</font></td>
  <td>    <button type="submit" id="submit" name="submit" value="1" /><font color="#663333">Forgot Password</font></td>
</tr>
</table>
<table align="center">

<tr>
<td align="right"><a href="registration.php" ><font color="#663333">New Registration</button></font></td>

</tr>

</table>
</form>
</div>
</div>
<?php
include("footer.php");

?>
</body>
</html>