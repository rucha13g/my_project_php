<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>

<body>
<div class="wrapper">
<div id="copyright">
<table align="center" style="border:none;margin-left:200px;">
<tr  >
<div style="margin-left:200px"><a href="terms.php">Tewms & condition</a> |<a href="privacy.php"> Privacy Policy </a>| <a href="contactus.php">Contact Us</a>
 | <a href="e-paper.php">E-Paper</a> |<a href="about.php"> About Us</a> | <a href="">News Paper</a> | <a href="rates.php">Rates & Offers</a> | <a href="faq.php">FAQ's</a></div>
</tr>
</table>
</div>

  <div id="copyright">
  <table style="border:none;"><tr class="fl_left" >

  <th >
  <a href="#"><img src="images/social1.png" /></a>
  </th>
  <th >
  <a href="#"><img src="images/social2.png" /></a>
  </th>
  <th>
  <a href="#"><img src="images/social3.png" /></a>
  </th>
    
  <th width="220"> </th>
   <th  align="center" style="margin-left:200px;margin-right:auto;"> Copyright &copy; 2014  Network</th>
     <th width="220"> </th>

 <th width="200">   <p class="fl_right"> <img src="images/card.png" width = "200" height="40"></a></p></th>
      </tr>

    </table>
  </div>
</div>
</body>
</html>