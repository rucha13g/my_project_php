<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>

<body>
<div class="wrapper">
  <div class="container">
   

  <!-- ####################################################################################################### -->
    <div id="hpage_latest">
      <ul>
        <li>
          <div class="imgholder"><a href="services.php".php"><img src="images/newspaper-text-classified-ad_2.jpg" width="260" height="180" alt="" /></a></div>
          <p><strong>Text Classified Ad</strong></p>
          <p>Economical,charges per lin/word,</p>
          <p>Ad appearing in simple running text,</p>
          <p>Enhance with Tick,Border &amp; Bold.</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
                         <p>&nbsp;</p>

          <p><a href="services.php"><img src="images/button_1.png"  /></a></p>
        </li>
        <li>
          <div class="imgholder"><a href="services.php"><img src="images/newspaper-display-classified-ad.jpg" width="260" height="180" alt="" /></a></div>
          <p><strong>Classified Display Ad</strong></p>
          <p>More Visible &amp; Expensive,</p>
          <p>Use images/logos + formatting,</p>
          <p>Rate charged on per sq.cm basis.</p>
          <p>&nbsp;</p>
               <p>&nbsp;</p>
                              <p>&nbsp;</p>

     
          
              <a href="services.php"><img src="images/button_2.png"  /></a>

        </li>
        <li class="last">
          <div class="imgholder"><a href="services1.php"><img src="images/newspaper-display-ad.jpg" width="260" height="180" alt="" /></a></div>
          <p><strong>Display Ad</strong></p>
          <p align="justify">Expensive (Rs.10,000+). Used by Businesses  for Large Advertising Spends,Ad appears beside editorial content,Use logo/ Images, Supplement Choice.</p>
                        <p>&nbsp;</p>

          <a href="services.php"><img src="images/button_3.png"  /></a>

        </li>
      </ul>
      <br class="clear" />
    </div>
  </div>
</div>

<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
  
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>