<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
	session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");

?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>State Details</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        
<?php
if(isset($_POST['submit']))
{
		$snm = $_POST['snm'];
		
 if(($snm == " "))
 {
	 echo "<script language='javascript'> alert('fill details');</script>";
 }
 else
 {
	$sql = "insert into tbl_state(state_name) values('$snm')";
	 $result = mysql_query($sql);
	 
	 if($result)
	 {
		echo "<script language = 'javascript'> alert('state insertion successfull');</script>";
	 }
 }
		
}
?>


                        <form method="post">
						<div class="sort">
                            <table>
                            <tr>
                            <td>State Name</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="snm" name="snm" required="required" class="field" style="width:191px;" />
							</td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
                <!-- Box -->
                
<?php		  
if(isset($_SERVER['PHP_SELF']))
{
$sql = "SELECT * from tbl_state where isdeleted = 0";
$result = mysql_query($sql) or die(mysql_error());
}
?>
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">List of State</h2>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
             <tr>
             <th>State Id</th><th>State Name</th><th>Edit</th><th>Delete</th>
             </tr>
             <?php    
					$sql = mysql_query("select * from tbl_state where isdeleted = 0 ORDER BY state_id ASC");
					$nr = mysql_num_rows($sql); // Get total of Num rows from the database query
			
					if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
						$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
				
					} else { // If the pn URL variable is not present force it to be value of page number 1
						$pn = 1;
					} 
			
					$itemsPerPage = 5; 
			
					$lastPage = ceil($nr / $itemsPerPage);
			
					if ($pn < 1) { // If it is less than 1
						$pn = 1; // force if to be 1
					} else if ($pn > $lastPage) { // if it is greater than $lastpage
						$pn = $lastPage; // force it to be $lastpage's value
					} 
			
					$centerPages = "";
					$sub1 = $pn - 1;
					$sub2 = $pn - 2;
					$add1 = $pn + 1;
					$add2 = $pn + 2;
					if ($pn == 1) {
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					} else if ($pn == $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
					} else if ($pn > 2 && $pn < ($lastPage - 1)) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
					} else if ($pn > 1 && $pn < $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					}
					
					$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
				
					$sql2 = "select * from tbl_state where isdeleted = 0 ORDER BY state_id ASC $limit";
					$paginationDisplay = ""; // Initialize the pagination output variable
			
					if ($lastPage != "1"){
						
						$paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
						
						if ($pn != 1) {
							$previous = $pn - 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> Back</a> ';
						} 
						
						$paginationDisplay .= '<span class="paginationNumbers">' . $centerPages . '</span>';
						
						if ($pn != $lastPage) {
							$nextPage = $pn + 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"> Next</a> ';
						} 
					}
					$result2 = mysql_query($sql2);
					
					if($nr < 1)
					{
						echo "<tr><td colspan='4' align='center'>No data exists</td></tr>";
					}
					else
					{
						while($row = mysql_fetch_array($result2)){ 
						
							$id = $row[0];
							$nm = $row[1];
							
							echo "<tr><td>$id</td><td>$nm</td><td><a href='edit_state.php?sid=$row[0]' class='ico edit'>Edit</a></td><td><a href='add_state.php?sid=$row[0]' class='ico del'>Delete</a></td></tr>";
							
						}
						
					}// close while loop
 
					
			?>
             
             </table>
             <?php echo "<div style='width: 100%; height: 25px; padding:6px; text-align: center;'>$paginationDisplay</div>";?>

						
                            
                            
                            <?php
							global $sid;
							if(isset($_SERVER['PHP_SELF']))
							{
							if(isset($_GET['sid']))
							{
								$sid1 = $_GET['sid'];
							
							$sql = "update tbl_state set isdeleted = 1 where state_id = $sid1";
							$result = mysql_query($sql);
							
							if($result)
							{
											echo "<script language = 'javascript'> window.location.href='add_state.php';</script>";
							}											
							}
							}
							 ?>

                         
							
                            					
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
					</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
</body>
<?php
include("admin_footer.php");

?>


</html>
