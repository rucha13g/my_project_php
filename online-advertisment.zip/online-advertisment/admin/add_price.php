<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
<script language="javascript" type="text/javascript">
function getper()
{
var p1 = document.getElementById("per").value;
document.getElementById("hidnper").value=p1;
}

function getcid()
{
var cid1 = document.getElementById("cid").value;
document.getElementById("hidn").value=cid1;
}
</script>

</head>

<body>
<?php
	session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("../session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
	
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Price Information </h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        <?php
						if(isset($_POST['submit']))
						{
								$amount = $_POST['amount'];								
								$did = $_POST['per'];
								$cid = $_POST['cid'];
						
								
							$sql = "insert into tbl_rate(rate_amount,d_id,city_id) values($amount,$did,$cid)";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('Rate successfully insert');</script>";
							 }
						 
								
						}
						?>
                        <form method="post">
                                     <input type="hidden" id="hidnper" name="hidnper" />
                                     <input type="hidden" id="hidn" name="hidn" />

						<div class="sort">
                            <table>
                            <tr>
                            <td>Amount</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="amount" name="amount" class="field" style="width:191px;" />
							</td>
                            </tr>
                            <tr>
                            <td>Discount</td>
                            <td></td>
                            <td>
						<select name="per" id="per" class="field" onchange="getper()" >
                                <option value="">--Select--</option>
                                <?php
                                if(isset($_SERVER['PHP_SELF']))
                                {
                                    $sql = "select * from tbl_discount ";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result))
                                    {
                                        echo "<option value = '$row[0]'>$row[1]</option>";
                                    }
                                }
                                ?>
                             </select>
                                </td>
                            </tr>
                            
                            <tr>
                            <td>City</td>
                            <td></td>
                            <td>
							<select name="cid" id="cid" class="field" onchange="getcid()" >
                                <option value="">--Select--</option>
                                <?php
                                if(isset($_SERVER['PHP_SELF']))
                                {
                                    $sql = "select c.city_id,c.city_name,s.state_name,c.state_id from tbl_city c,tbl_state s where c.isdeleted = 0 and s.state_id = c.state_id ";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result))
                                    {
                                        echo "<option value = '$row[0]'>$row[1]-$row[2]</option>";
                                    }
                                }
                                ?>
                             </select>
                             </td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
                <!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">List of Price</h2>
					</div>
					<!-- End Box Head -->	
<?php		  
if(isset($_SERVER['PHP_SELF']))
{
$sql = "SELECT r.rate_id,r.rate_amount,d.per,c.city_name,s.state_name from tbl_rate r,tbl_city c,tbl_state s,tbl_discount d where c.city_id = r.city_id and c.state_id = s.state_id and d.d_id = r.d_id and r.isdeleted = 0";
$result = mysql_query($sql) or die(mysql_error());
}
?>

					<!-- Table -->
							<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
             <tr>
             <th>Price Id</th><th>Amount</th><th>Discount</th><th>City</th><th>Edit</th><th>Delete</th>
             </tr>
             <?php    
					$sql = mysql_query("SELECT r.rate_id,r.rate_amount,d.per,c.city_name,s.state_name from tbl_rate r,tbl_city c,tbl_state s,tbl_discount d where c.city_id = r.city_id and c.state_id = s.state_id and d.d_id = r.d_id and r.isdeleted = 0 ORDER BY r.rate_id ASC");
					$nr = mysql_num_rows($sql); // Get total of Num rows from the database query
			
					if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
						$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
				
					} else { // If the pn URL variable is not present force it to be value of page number 1
						$pn = 1;
					} 
			
					$itemsPerPage = 5; 
			
					$lastPage = ceil($nr / $itemsPerPage);
			
					if ($pn < 1) { // If it is less than 1
						$pn = 1; // force if to be 1
					} else if ($pn > $lastPage) { // if it is greater than $lastpage
						$pn = $lastPage; // force it to be $lastpage's value
					} 
			
					$centerPages = "";
					$sub1 = $pn - 1;
					$sub2 = $pn - 2;
					$add1 = $pn + 1;
					$add2 = $pn + 2;
					if ($pn == 1) {
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					} else if ($pn == $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
					} else if ($pn > 2 && $pn < ($lastPage - 1)) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
					} else if ($pn > 1 && $pn < $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					}
					
					$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
				
					$sql2 = "SELECT r.rate_id,r.rate_amount,d.per,c.city_name,s.state_name from tbl_rate r,tbl_city c,tbl_state s,tbl_discount d where c.city_id = r.city_id and c.state_id = s.state_id and d.d_id = r.d_id and r.isdeleted = 0 ORDER BY r.rate_id ASC $limit";
					$paginationDisplay = ""; // Initialize the pagination output variable
			
					if ($lastPage != "1"){
						
						$paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
						
						if ($pn != 1) {
							$previous = $pn - 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> Back</a> ';
						} 
						
						$paginationDisplay .= '<span class="paginationNumbers">' . $centerPages . '</span>';
						
						if ($pn != $lastPage) {
							$nextPage = $pn + 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"> Next</a> ';
						} 
					}
					$result2 = mysql_query($sql2);
					
					if($nr < 1)
					{
						echo "<tr><td colspan='4' align='center'>No data exists</td></tr>";
					}
					else
					{
						while($row = mysql_fetch_array($result2)){ 
						
							$rid = $row[0];
							$amount = $row[1];
							$per = $row[2];
							$city = $row[3];
							$state = $row[4];

							echo "<tr><td>$rid</td><td>$amount</td><td>$per %</td><td>$city-$state</td><td><a href='edit_price.php?rid=$row[0]' class='ico edit'>Edit</a></td><td><a href='add_price.php?rid=$row[0]' class='ico del'>Delete</a></td></tr>";
							
						}
						
					}// close while loop
 
					
			?>
             
             </table>
             <?php echo "<div style='width: 100%; height: 25px; padding:6px; text-align: center;'>$paginationDisplay</div>";?>	
			 
             	<?php
							global $cid;
							if(isset($_SERVER['PHP_SELF']))
							{
							if(isset($_GET['rid']))
							{
								$rid1 = $_GET['rid'];
							
							$sql = "update tbl_rate set isdeleted = 1 where city_id = $rid1";
							$result = mysql_query($sql);
							
							if($result)
							{
											echo "<script language = 'javascript'> window.location.href='add_price.php';</script>";
							}											
							}
							}
							 ?>

							</table>
						
						
					
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
			</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
