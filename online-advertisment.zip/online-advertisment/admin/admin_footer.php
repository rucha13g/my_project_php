a<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Free CSS template by ChocoTemplates.com</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>
<body>
		
<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left">&copy; 2014 - Advertisment</span>
		<span class="right">
			Design by <a href="#" target="_blank" >xxxxxxx.in</a>
		</span>
	</div>
</div>
<!-- End Footer -->
	
</body>
</html>