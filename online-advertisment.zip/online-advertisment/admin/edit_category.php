<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Category Information</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        <?php
global $cid1,$catnm1,$img1;
if(isset($_SERVER['PHP_SELF']))
{
	
if(isset($_GET['cid']))
{
	$cid1 = $_GET['cid'];
	
$sql = "SELECT c_id,c_name,c_img from tbl_category where isdeleted = 0 and c_id = '$cid1' ";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
		$cid1 = $row[0];
		$catnm1 = $row[1];	
		$img1 = $row[2];	

}
}
}

?>


						 <?php
						if(isset($_POST['submit']))
						{
								$catnm = $_POST['catnm'];
								
									if($_FILES["image0"]["name"] == ''){
										 $img1 = $_POST['image1'];
									}
									else{
										 $img1 = $_FILES['image0']['name'];
									}
								 move_uploaded_file($img1,'upload/'.$img1);


								
							$sql = "update tbl_category set c_name = '$catnm',c_img = '$img1' where c_id = '$cid1' and isdeleted = 0 ";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('Category successfully insert');</script>";
																echo "<script language = 'javascript'> window.location.href='add_category.php';</script>";

							 }
						 
								
						}
						?>

                        <form method="post" enctype="multipart/form-data">
						<div class="sort">
                            <table>
                            <tr>
                            <td>Category Name</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="catnm" name="catnm" class="field" style="width:191px;" required="required" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $catnm1;} ?>" />
							</td>
                            </tr>
                            
                           
                            <tr>
                            <td>Image</td>
                            <td></td>
                             <td><input type="file" name="image0" id="image0" /></td>
                             <td><input type="hidden" name="image1" id="image1"  value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $img1;} ?>
"/></td>

							 </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->
				
           </div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
