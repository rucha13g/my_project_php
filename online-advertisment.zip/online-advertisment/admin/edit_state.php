<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>State Details</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
<?php
global $sid1,$snm1;
if(isset($_SERVER['PHP_SELF']))
{
	
if(isset($_GET['sid']))
{
	$sid = $_GET['sid'];
	
$sql = "SELECT state_id,state_name from tbl_state where isdeleted = 0 and state_id = '$sid' ";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
		$sid1 = $row[0];
		$snm1 = $row[1];	
}
}
}

?>

                        
<?php
if(isset($_POST['submit']))
{
		$snm = $_POST['snm'];
		
 if(($snm == " "))
 {
	 echo "<script language='javascript'> alert('fill details');</script>";
 }
 else
 {
	$sql = "update tbl_state set state_name = '$snm' where state_id = '$sid'";
	 $result = mysql_query($sql) or die(mysql_error());
	 
	 if($result)
	 {
		echo "<script language = 'javascript'> alert('state update successfull');</script>";
	    		echo "<script language = 'javascript'> window.location.href='add_state.php';</script>";
	 }
 }
		
}
?>
                      <form method="post">
						<div class="sort">
                            <table>
                            <tr>
                            <td>State Name</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="snm" name="snm"  class="field" style="width:191px;" value="<?php if(isset($_SERVER['PHP_SELF'])) echo $snm1; ?>" />
							</td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
                <!-- Box -->
                
           		</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
</body>
<?php
include("admin_footer.php");

?>


</html>
