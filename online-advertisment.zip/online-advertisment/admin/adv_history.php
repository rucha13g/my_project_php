<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
	
	//$unm1 = $_SESSION['user']; 

include("connection.php");
//include("session_out.php");

include("admin_header.php");

?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Booked Advertisment Details</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        
<?php
if(isset($_SERVER['PHP_SELF']))
{
	$sql = "SELECT c.city_name,s.state_name,cat.c_name,p.papername,r.rate_amount,txt.ad_book_date,txt.ad_display_date\n"
    . "from tbl_city c,tbl_state s,tbl_category cat,tbl_txt_ad txt,tbl_paper p,tbl_rate r\n"
    . "where cat.c_id=txt.c_id and s.state_id = txt.state_id and c.city_id = txt.city_id and p.paper_id = txt.paper_id and r.rate_id = txt.rate_id LIMIT 0, 30 ";
	$result = mysql_query($sql);
	
}
?>


                        <form method="post">
						<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                            <td>City Name</td><td>State Name</td><td>Category Name</td><td>Paper Name</td><td>Amount</td><td>Book Date</td><td>Display Date</td></tr>
                            <?php
							while($row = mysql_fetch_array($result))
							{
								echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td><td>$row[6]</td></tr>";
							}
							
							
							?> 
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
                <!-- Box --><!-- End Box -->
					</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
</body>
<?php
include("admin_footer.php");

?>


</html>
