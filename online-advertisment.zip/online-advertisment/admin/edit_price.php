<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
<script language="javascript" type="text/javascript">
function getper()
{
var p1 = document.getElementById("per").value;
document.getElementById("hidnper").value=p1;
}

function getcid()
{
var cid1 = document.getElementById("cid").value;
document.getElementById("hidn").value=cid1;
}
</script>

</head>

<body>
<?php
session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Price Information </h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						

						<!-- Sort -->
<?php
global $rid1,$amount1,$cid1,$did1;
if(isset($_SERVER['PHP_SELF']))
{
	
if(isset($_GET['rid']))
{
	$rid1 = $_GET['rid'];
	
$sql = "SELECT rate_id,rate_amount,city_id,d_id from tbl_rate where isdeleted = 0 and rate_id = '$rid1' ";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
		$rid1 = $row[0];
		$amount1 = $row[1];	
				$cid1 = $row[2];	

		$did1 = $row[3];	
		

}
}
}

?>

                        <?php
						if(isset($_POST['submit']))
						{
								$amount = $_POST['amount'];
								
								if($_POST['per'] == '')
									{
										 $did = $_POST['did1'];
									}
									else{
										 $did = $_POST['per'];
									}
						
								if($_POST['cid'] == '')
											{
												 $cid = $_POST['cid1'];
											}
											else{
												 $cid = $_POST['cid'];
											}
							$sql = "update tbl_rate set rate_amount = '$amount',d_id = '$did',city_id = '$cid' where rate_id = '$rid1'";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('Rate successfully insert');</script>";
								echo "<script language = 'javascript'> window.location.href='add_price.php';</script>";

							 }
						 
								
						}
						?>
                        <form method="post">
                                     <input type="hidden" id="hidnper" name="hidnper" />
                                     <input type="hidden" id="hidn" name="hidn" />

						<div class="sort">
                            <table>
                            <tr>
                            <td>Amount</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="amount" name="amount" class="field" style="width:191px;" value="<?php if(isset($_SERVER['PHP_SELF'])) echo $amount1; ?>" />
							</td>
                            </tr>
                            <tr>
                            <td>Discount</td>
                            <td></td>
                            <td>
						<select name="per" id="per" class="field" onchange="getper()" / >
                                <option value="">--Select--</option>
                                <?php
                                if(isset($_SERVER['PHP_SELF']))
                                {
                                    $sql = "select * from tbl_discount ";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result))
                                    {
                                        echo "<option value = '$row[0]'>$row[1]</option>";
                                    }
                                }
                                ?>
                             </select>
                                </td>
                                  <td><input type="hidden" name="did1" id="did1"  value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $did1;}  ?>
"/></td>
                            </tr>
                            
                            <tr>
                            <td>City</td>
                            <td></td>
                            <td>
							<select name="cid" id="cid" class="field" onchange="getcid()" >
                                <option value="">--Select--</option>
                                <?php
                                if(isset($_SERVER['PHP_SELF']))
                                {
                                    $sql = "select c.city_id,c.city_name,s.state_name,c.state_id from tbl_city c,tbl_state s where c.isdeleted = 0 and s.state_id = c.state_id ";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result))
                                    {
                                        echo "<option value = '$row[0]'>$row[1]-$row[2]</option>";
                                    }
                                }
                                ?>
                             </select>
                             </td>
                               <td><input type="hidden" name="cid1" id="cid1"  value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $cid1;}  ?>
"/></td>
                            </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
				</div>
				<!-- End Box -->
				
			</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
