<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
<script language="javascript" type="text/javascript">
function getsid()
{
var sid1 = document.getElementById("sid").value;
document.getElementById("hidn").value=sid1;
}
</script>

</head>

<body>
<?php
session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
	
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>City Details</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        
<?php
global $cid1,$cnm1,$sid1;
if(isset($_SERVER['PHP_SELF']))
{
	
if(isset($_GET['cid']))
{
	$cid1 = $_GET['cid'];
	
$sql = "SELECT city_id,city_name,state_id from tbl_city where isdeleted = 0 and city_id = '$cid1' ";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
		$cid1 = $row[0];
		$cnm1 = $row[1];	
		$sid1 = $row[2];	

}
}
}

?>

                        <?php
						if(isset($_POST['submit']))
						{
								$cnm = $_POST['cnm'];
								
								if($_POST['sid'] == '')
									{
										 $sid = $_POST['sid1'];
									}
									else{
										 $sid = $_POST['sid'];
									}
						
								
							$sql = "update tbl_city set city_name = '$cnm',state_id = '$sid' where city_id = '$cid1'";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('updated');</script>";
								echo "<script language = 'javascript'> window.location.href='add_city.php';</script>";

							 }
						}
						?>

                        <form method="post">
                                        <input type="hidden" id="hidn" name="hidn" />

						<div class="sort">
                            <table>
                            <tr>
                            <td>City Name</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="cnm" name="cnm" class="field" style="width:191px;" required="required"  value="<?php if(isset($_SERVER['PHP_SELF'])) echo $cnm1; ?>" />
							</td>
                            </tr>
                            
                            <tr>
                            <td>State Name</td>
                            <td></td>
                            <td>
							<select name="sid" id="sid" class="field" onchange="getsid()" >
                                <option value="">--Select--</option>
                                <?php
                                if(isset($_SERVER['PHP_SELF']))
                                {
                                    $sql = "select * from tbl_state ";
                                    $result = mysql_query($sql);
                                    while($row = mysql_fetch_array($result))
                                    {
                                        echo "<option value = '$row[0]'>$row[1]</option>";
                                    }
                                }
                                ?>
                             </select>
                            </td>
                            <td><input type="hidden" name="sid1" id="sid1"  value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $sid1;}  ?>
"/></td>

                            </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

				</div>
				<!-- End Box -->
			</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
