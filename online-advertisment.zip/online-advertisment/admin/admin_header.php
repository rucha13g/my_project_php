<?php
error_reporting(0);

include("connection.php");
global $unm1;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Free CSS template by ChocoTemplates.com</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>
<body>
<!-- Header -->
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
        
			<h1><a href="">Advertisment</a></h1>
            
			<div id="top-navigation">
  				<?php
					session_start();
					$unm1 = $_SESSION['user']; 
					if($unm1 == NULL)
					{
						echo "<td><font color='#FF0000'><a href='../login.php'><b>SignIn</b></a></font></td>";
						echo "<td><font color='#CCCCCC'>|</font></td>";
						echo "<td><font color='#999999'>Not Registered </font><font color='#FF0000'><a href='registration.php'><b>SignUp</b></a></font></td>";
						echo "</tr>";
					}
					else
					{
						echo "Welcome "."<b>".strtoupper($unm1)."</b>" ;
						echo "<td><font color='#CCCCCC'>|</font></td><td><font color='#FF0000'><a href='../logout.php'><b>Logout</b></a></font></td>";
						
					}
				?>
          </div>
		</div>
		<!-- End Logo + Top Nav -->
		
		<!-- Main Nav -->
		<div id="navigation">
			<ul>
			    <li><a href="home_index.php" class="active"><span>HOME</span></a></li>
			    <li><a href="add_newspaper.php"><span>NEWS PAPER</span></a></li>
			    <li><a href="add_state.php"><span>STATE</span></a></li>
			    <li><a href="add_city.php"><span>CITY</span></a></li>
			    <li><a href="add_price.php"><span>PRICE</span></a></li>
			    <li><a href="add_discount.php"><span>DISCOUNT</span></a></li>
			    <li><a href="add_category.php"><span>CATEGORY</span></a></li>
                <li><a href="adv_history.php"><span>HISTRY</span></a></li>
			    <li><a href="pd.php"><span>PASSWORD</span></a></li>
			</ul>
		</div>
		<!-- End Main Nav -->
	</div>
</div>
<!-- End Header -->

	</body>
</html>