<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");

include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Discount Information</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
                        <?php
global $did1,$per;
if(isset($_SERVER['PHP_SELF']))
{
if(isset($_GET['did']))
{
	$did1 = $_GET['did'];
	
$sql = "select d_id,per from tbl_discount where d_id = '$did1'";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result))
{
		$did1 = $row[0];
		$per1 = $row[1];	

}
}
}

?>


                        <?php
						if(isset($_POST['submit']))
						{
								$per = $_POST['per'];
								
						 if(($per == " "))
						 {
							 echo "<script language='javascript'> alert('fill details');</script>";
						 }
						 else
						 {
							$sql = "update tbl_discount set per = '$per' where d_id = '$did1'";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('Updated');</script>";
								echo "<script language = 'javascript'> window.location.href='add_discount.php';</script>";

							 }
						 }
								
						}
						?>


                        <form method="post">
						<div class="sort">
                            <table>
                            <tr>
                            <td>Percentage</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="per" name="per" class="field" style="width:191px;" value="<?php if(isset($_SERVER['PHP_SELF'])) echo $per1; ?>" />
							</td>
                            </tr>
                            
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                

				</div>
				<!-- End Box -->
			</div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
