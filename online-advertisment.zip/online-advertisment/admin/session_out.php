<?php
if(!isset($_SESSION['user']) || (trim($_SESSION['user']) == ''))
	 {
    header("location: index.php");
    exit();
    } 
?>