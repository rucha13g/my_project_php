<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
	session_start();
	$unm = $_SESSION['user']; 

include("connection.php");
include("../session_out.php");
include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		<!-- Small Nav -->
		<div class="small-nav">
			<a href="../admin_index.php">Home</a>
			<span>&gt;</span>
<span>&gt;</span>
            			<a href="add_category.php">State</a>		</div>
		<!-- End Small Nav -->
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
            

                
                <!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">List of Categories</h2>
					</div>
					<!-- End Box Head -->	

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <?php 
      if(isset($_POST['submit']))
      {
		   if($_POST['submit'] == 0)
   {
      $opd=$_POST['opd'];
      $npd=$_POST['npd'];
      $cpd=$_POST['cpd'];   
	  if($npd == $cpd)
      {  
      $sql="update tbl_login set password='$cpd' where username='$unm';";
      $result = mysql_query($sql);
	  
	    $sql="update tbl_user set password='$cpd' where emailid='$unm';";
      $result1 = mysql_query($sql);
	  if($result || $result1)
	  {	
	  echo "<script language = 'javascript'> alert('password successfully updated');</script>";
	      		echo "<script language = 'javascript'> window.location.href='change_pd.php';</script>";

       }  
   }
   }

	  	  
	  }
       
      ?>
           
						<form method="post">
       <table align="center">
       <tr>
       <td>Email Id</td>
       <td><input type="text" id="unm" name="unm" readonly="readonly" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $unm;}														
																		 ?>"/></td>
       </tr>
       <tr>
       <td>Old Password</td>
       <td><input type="password" id="opd" name="opd" /></td>
       </tr>
       <tr>
       <td>New Password</td>
       <td><input type="password" id="npd" name="npd" /></td>
       </tr>
       <tr>
       <td>Confirm Password</td>
       <td><input type="password" id="cpd" name="cpd" /></td>
       </tr>
       </table>
       <table align="center">
       <tr>
       <td><button type="submit" id="submit" name="submit" value="0"  style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;">Save Password</button></td>
       </tr>            
       </table>   
</form>    
						
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
           </div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
