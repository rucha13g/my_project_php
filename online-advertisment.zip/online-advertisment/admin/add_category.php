<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Online-Advertisment</title>
	<link rel="stylesheet" href="css-admin/style.css" type="text/css" media="all" />
</head>

<body>
<?php
	session_start();
	$unm1 = $_SESSION['user']; 

include("connection.php");
include("session_out.php");
include("admin_header.php");
?>
<!-- Container -->
<div id="container">
	<div class="shell">
		
		
		
		<br />
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content">
				
			    
		
                <!-- Box-add -->
				<div class="box" >
					
					<!-- Box Head -->
					<div class="box-head">
						<h2>Category Information</h2>
					</div>
					<!-- End Box Head-->
					
					<div class="box-content">
						
<!--						<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>
-->						
						<!-- Sort -->
						 <?php
						if(isset($_POST['submit']))
						{
								$catnm = $_POST['catnm'];
								$image = trim($_FILES['image0']['name']);

								
							$sql = "insert into tbl_category(c_name,c_img) values('$catnm','$image')";
							 $result = mysql_query($sql);
							 
							 if($result)
							 {
								echo "<script language = 'javascript'> alert('Category successfully insert');</script>";
							 }
						 
								
						}
						?>

                        <form method="post" enctype="multipart/form-data">
						<div class="sort">
                            <table>
                            <tr>
                            <td>Category Name</td>
                            <td></td>
                            <td>                            
                            <input type="text" id="catnm" name="catnm" class="field" style="width:191px;" required="required" />
							</td>
                            </tr>
                            
<?php
if(isset($_FILES['image0']))
{
    $file_name0 = $_FILES['image0']['name'];
    $file_tmp = $_FILES['image0']['tmp_name'];
    $file_size = $_FILES['image0']['size'];
   // echo $file_size;
	
    if($_FILES['image0']['size'] > 10485760)
    {
        echo "<br><br>Photo size is greater";
        
    }
    else
    {
        if(move_uploaded_file($file_tmp,'upload/'.$file_name0))
        {
			
//$sql = "insert into tbl_brand brand_logo values('$file_name0')";
//$result = mysql_query($sql);
          echo "<br><br>logo uploaded";
           //header('Location: http://localhost/rucha/upload/'. $file_name0); 
        }
    }
}
?>
                            <tr>
                            <td>Image</td>
                            <td></td>
                             <td><input type="file" name="image0" id="image0" /></td>
							 </tr>
                            </table>
                            <table>
                            <tr>
                            <td>
                            <input type="submit" id="submit" name="submit" value="Submit" style="background-color:#CCCC00;border:solid 3px #CC9900;border-radius:5px;margin-left:170px;margin-right:auto;margin-top:10px;" />
                            </td>
                            </tr>
                            
							</table>
						</div>
                        </form>
						<!-- End Sort -->
						
					</div>
				</div>
				<!-- End Box-add -->

                
                <!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">List of Categories</h2>
					</div>
					<!-- End Box Head -->	
<?php		  
if(isset($_SERVER['PHP_SELF']))
{
$sql = "SELECT c_id,c_name,c_img from tbl_category where isdeleted = 0";
$result = mysql_query($sql) or die(mysql_error());
}
?>

					<!-- Table -->
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
             <tr>
             <th>City Id</th><th>City Name</th><th>State Name</th><th>Edit</th><th>Delete</th>
             </tr>
             <?php    
					$sql = mysql_query("SELECT c_id,c_name,c_img from tbl_category where isdeleted = 0 ORDER BY c_id ASC");
					$nr = mysql_num_rows($sql); // Get total of Num rows from the database query
			
					if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
						$pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
				
					} else { // If the pn URL variable is not present force it to be value of page number 1
						$pn = 1;
					} 
			
					$itemsPerPage = 5; 
			
					$lastPage = ceil($nr / $itemsPerPage);
			
					if ($pn < 1) { // If it is less than 1
						$pn = 1; // force if to be 1
					} else if ($pn > $lastPage) { // if it is greater than $lastpage
						$pn = $lastPage; // force it to be $lastpage's value
					} 
			
					$centerPages = "";
					$sub1 = $pn - 1;
					$sub2 = $pn - 2;
					$add1 = $pn + 1;
					$add2 = $pn + 2;
					if ($pn == 1) {
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					} else if ($pn == $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
					} else if ($pn > 2 && $pn < ($lastPage - 1)) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
					} else if ($pn > 1 && $pn < $lastPage) {
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
						$centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
						$centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
					}
					
					$limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage; 
				
					$sql2 = "SELECT c_id,c_name,c_img from tbl_category where isdeleted = 0 ORDER BY c_id ASC $limit";
					$paginationDisplay = ""; // Initialize the pagination output variable
			
					if ($lastPage != "1"){
						
						$paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
						
						if ($pn != 1) {
							$previous = $pn - 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"> Back</a> ';
						} 
						
						$paginationDisplay .= '<span class="paginationNumbers">' . $centerPages . '</span>';
						
						if ($pn != $lastPage) {
							$nextPage = $pn + 1;
							$paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"> Next</a> ';
						} 
					}
					$result2 = mysql_query($sql2);
					
					if($nr < 1)
					{
						echo "<tr><td colspan='4' align='center'>No data exists</td></tr>";
					}
					else
					{
						while($row = mysql_fetch_array($result2)){ 
						
							$cid = $row[0];
							$cnm = $row[1];
							$img = $row[2];
							
							echo "<tr><td>$cid</td><td>$cnm</td><td><img src='upload/$img' width='180px' height=60px'></td><td><a href='edit_category.php?cid=$row[0]' class='ico edit'>Edit</a></td><td><a href='add_category.php?cid=$row[0]' class='ico del'>Delete</a></td></tr>";
							
						}
						
					}// close while loop
 
					
			?>
             
             </table>
             <?php echo "<div style='width: 100%; height: 25px; padding:6px; text-align: center;'>$paginationDisplay</div>";?>	
			 	<?php
							global $cid;
							if(isset($_SERVER['PHP_SELF']))
							{
							if(isset($_GET['cid']))
							{
								$cid1 = $_GET['cid'];
							
							$sql = "update tbl_category set isdeleted = 1 where c_id = $cid1";
							$result = mysql_query($sql);
							
							if($result)
							{
											echo "<script language = 'javascript'> window.location.href='add_category.php';</script>";
							}											
							}
							}
							 ?>

							</table>
						
						
						
					</div>
					<!-- Table -->
					
				</div>
				<!-- End Box -->
				
           </div>
			<!-- End Content -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->
<?php
include("admin_footer.php");

?>

</body>


</html>
