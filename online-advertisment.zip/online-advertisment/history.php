<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout1.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>

</head>
<body>
<?php
include("header.php");
include("login-box.php");

include("user_menu.php");
include("connection.php");
 session_start();
 $unm = $_SESSION['user'];   
 include("session_out.php");



?>
<?php
global $tid,$amount;

?>
<div class="container">

  <table summary="Summary Here" cellpadding="0" cellspacing="0" align="center">
  <tr>
  <td>
<a href="withoutimage.php"><input type="radio"   />Simple Ad</a>

<a href="histryimg.php"><input type="radio"  />Display ad</a>
</td>
   </table>           
         
            
</div>
<?php
include("footer.php");

?>
</body>
</html>