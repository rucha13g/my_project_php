<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>

</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("user_menu.php");

include("connection.php");
 session_start();
 $unm = $_SESSION['user'];   
include("session_out.php");

?>
<?php
global $id,$nm1,$no1,$unm1;
if(isset($_SERVER['PHP_SELF']))
{
$sql1 = "select * from tbl_user where emailid = '" . trim($unm) . "' and isdeleted = 0";
    $result1 = mysql_query($sql1);   
	$count = mysql_num_rows($result1);
    while($row1 = mysql_fetch_array($result1))
    {
		$id = $row1[0];
		$nm1 = $row1[1];
		$no1 = $row1[2];
		$unm1 = $row1[3];

	}		
	
}
?>

  <div class="container">
   <div id="respond">

<form method="post" >
<table  align="center">

<tr>
<td><b>Name</b></td>
<td><input type="text" id="nm" name="nm" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $nm1;} ?>" />

</td>
</tr>

<tr>
<td><b>Contact No.</b></td>
<td><input type="text" id="no" name="no" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $no1;}														
																		 ?>" />
</td>
</tr>

<tr>
<td><b>Email Id</b></td>
<td><input type="text" id="unm" name="unm" readonly="readonly" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $unm1;}														
																		 ?>" />
</td>
</tr>
</table>
<table align="center">
<tr>
<td><input type="submit" id="submit" name="submit" value="Update Profile" /></td>
</tr>
</table>
</form>
   <?php

if(isset($_POST['submit']))
{
	$nm = trim($_POST['nm']);
	$unm = trim($_POST['unm']);
    $no = trim($_POST['no']);
	
 	 $sql = "update tbl_user set name = '$nm',contactno = '$no' where emailid = '$unm' and isdeleted = 0";
	 $result = mysql_query($sql);
	 
	 if($result)
	 {
		echo "<script language = 'javascript'> alert('updated');</script>";
		    		echo "<script language = 'javascript'> window.location.href='profile.php';</script>";

	 }

	
}
?>

</div>
</div>
<?php
include("footer.php");

?>
</body>
</html>