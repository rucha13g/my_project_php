<?php
include("connection.php");
	
	$cid=$_REQUEST['city'];

?>


   News-Paper&nbsp; &nbsp;&nbsp;&nbsp;<select name="paper" id="paper"  style="width:155px;" onchange="ajax_paper(this.value)">
  
    <option >--Select--</option>
            <?php
			if(isset($_SERVER['PHP_SELF']))
			{
				$sql = "select * from tbl_paper where isdeleted=0 and city_id = $cid";
				$result = mysql_query($sql) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					$sid = $r[0];
					echo "<a href=book_adv.php?pid=$r[0]><option value = '$row[0]'>$row[1]</option>";
				}
	    	}
		  
?>
</select>
