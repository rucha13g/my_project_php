<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Network</title>
<link rel="stylesheet" href="admin/css-admin/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="login-box.css" type="text/css" media="all" />

<script language="javascript" type="text/javascript">
function validEmail(email)
{
    var email = document.getElementById("unm").value; 
    var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
    if (reg.test(email))
    {
        return true;
    }
    else{
        alert('Enter proper Email id');
    }
}



</script>

</head>

<body>
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
			<h1><a href="#">Advertisment</a></h1>

		</div>
</div>
</div>

<?php
include("connection.php");
$count = 0;
  	
if(isset($_POST['submit']))
{
    if($_POST['submit'] == 0)
    {
	$unm = trim($_POST['unm']);
	$pd = trim($_POST['pd']);
	
//for validation...1
     if(($unm == " ") && ($pd == " "))
     {
    	 echo "<script language='javascript'> alert('fill details');</script>";
     }
     else
     { 	 
	  	 $sql = "select * from tbl_login where username = '$unm' and password = '$pd' and isdeleted = 0";
    	 $result = mysql_query($sql);
         $count = mysql_num_rows($result);           	 
    	 if($count >= 1)
          	 {
			 while($row = mysql_fetch_array($result))
			 {
				 $type = $row[3];
			 }
			
			 if($type == "admin")
			{
		    session_start();
            $_SESSION['user'] = $unm;

    		echo "<script language = 'javascript'> window.location.href='admin/index.php';</script>";
			}
			
   		 }
		 
 	 }

 	 }
	if($_POST['submit'] == 1)
 {
 
	$pd = trim($_POST['pd']);
    $unm = trim($_POST['unm']);
    $sql1 = "select * from tbl_login where username = '$unm' and isdeleted = 0";
    $result1 = mysql_query($sql1) or die(mysql_error());				
		while( $row1 = mysql_fetch_array($result1))		
		{
		
		 function genpwd($cnt)  
				{  
				// characters to be included for randomization, here you can add or delete the characters   
				   			  
				 $pwd = str_shuffle('abcefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@#%$*');  
				  
				// here specify the 2nd parameter as start position, it can be anything, default 0   
				  				  
				 return substr($pwd,0,$cnt);   
				}
				$password = genpwd(8);
	             $to = $_POST['unm'];
               // $subject = $_POST['subtxt'];
                //$msg = $_POST['msgtxt'];
            	include ("class.phpmailer.php"); // include the class name
				$mail = new PHPMailer(); // create a new object
				$mail->IsSMTP(); // enable SMTP
				$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
				$mail->SMTPAuth = true; // authentication enabled
				$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for GMail
				//$mail->Host = "208.91.199.120";
                $mail->Host = "plus.smtp.mail.yahoo.com";
				$mail->Port = 465; // or 587
				$mail->IsHTML(true);
				$mail->Username = "desire_infotech@yahoo.com";
				$mail->Password = "India@123";
				$mail->SetFrom("desire_infotech@yahoo.com");
				//$mail->Subject = $subject;
				$mail->Body = $password;
				$mail->AddAddress($to);
                if(!$mail->Send()){
					
					
					echo "<script language='javascript'>alert('" . $mail->ErrorInfo . "');</script>";
				}
				else{
					echo "<script language='javascript'>alert('Password has been sent');</script>";
				}
				$sql4 = "update tbl_login set password = '$password' where username = '$unm'";
		$result4 = mysql_query($sql4);
		
		$sql5 = "update tbl_user set password = '$password' where emailid = '$unm'";
		$result5 = mysql_query($sql5);
}
 }

	
	
}
 

?>
<div style="margin-left:auto;margin-right:auto;">

</div>


<table align="center">
<img src="images/login.gif"  />

</table>

<form method="post">
<table align="center" style="margin-left:500px;">
<tr>
<td><font color="#CC3300" face="Arial, Helvetica, sans-serif">User Name</font></td>
<td></td>
<td><input type="text" id="unm" name="unm" onchange="validEmail(this.event);" style="margin-top:5px; width:191px;height:25px; border:#333333;border-collapse:collapse;border:groove;"/></td>
</tr>
<tr>
<td><font color="#CC3300" face="Arial, Helvetica, sans-serif">Password</font></td>
<td></td>

<td><input type="password" id="pd" name="pd" style="margin-top:5px; width:191px;height:25px; border:#333333;border-collapse:collapse;border:groove;" /></td>
</tr>
</table>
<table align="center"  style="margin-left:600px;">
<tr>
<td><button type="submit" id="submit" name="submit" value="0" style="background-color:#CCCC00;border:ridge 2px #CC9900;border-radius:3px;"/>Log In</button></td>
<td><button type="submit" id="submit" name="submit" value="1" style="background-color:#CCCC00;border:ridge 2px #CC9900;border-radius:3px;"/>Forgot Password</button></td>


</tr>
</table>
</form>


</body>
</html>