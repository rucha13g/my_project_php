<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout1.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script language="javascript" type="text/javascript">

function ajax_simple(pr)
	{		
		var a;
		if(window.XMLHttpRequest)
		{
			a=new XMLHttpRequest;
		}
		else
		{
			a=new activexObject("microsoft.XMLHTTP");
			
		}
		
		a.open("GET","ajas_s.php?sad="+pr,true);
		a.send();
		a.onreadystatechange= function()
		{
			if(a.readyState==4)
			{
				document.getElementById("simple").innerHTML=a.responseText;
			}
		}
	}	
</script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");

include("user_menu.php");
include("connection.php");
 session_start();
 $unm = $_SESSION['user'];   
 include("session_out.php");



?>
<?php
global $tid,$amount;

?>
<div class="container">

  <table summary="Summary Here" cellpadding="0" cellspacing="0" align="center">
          <thead>
            <tr>
              <th>Category</th>
              <th>Heading</th>
              <th>Description</th>
              <th>Footer </th>
              <th>Image </th>
              <th>Book Date </th>
              <th>Display Date </th>
              <th>Amount </th>
              
              <?php 
			  
			    $sql = "select user_id from tbl_user where emailid= '$unm' and isdeleted = 0";
			  $result = mysql_query($sql) or die(mysql_error());
			  while($r = mysql_fetch_array($result))
{
	$uid = $r[0];
	//echo "uid". $uid;
}
			  $sql = "select p.txt_ad_id,p.payment_amount from tbl_payment p,tbl_user u where p.user_id = $uid ";
			  $result = mysql_query($sql) or die(mysql_error());
			  while($r = mysql_fetch_array($result))
			{
				$tid = $r[0];
				$amount = $r[1];
				//echo $tid;exit;
			}
			 
			  $sql = "select c.c_name,t.ad_heading,t.txt_ad_description,t.ad_footer,t.ad_img,t.ad_book_date,t.ad_display_date,p.payment_amount 
			   from tbl_payment p,tbl_txt_ad t,tbl_category c where p.user_id = $uid and t.c_id = c.c_id and t.txt_ad_id = $tid";
$result = mysql_query($sql) or die(mysql_error());
while($r = mysql_fetch_array($result))
{
	echo "<tbody><td>$r[0]</td><td>$r[1]</td><td>$r[2]</td><td>$r[3]</td><td><img src='upload/$img' width='140px' height=40px'></td><td>$r[5]</td><td>$r[6]</td><td>$r[7]</td></tbody>";
}

?>
   </tr>
   </thead>
   </table>           
         
            
</div>
<?php
include("footer.php");

?>
</body>
</html>