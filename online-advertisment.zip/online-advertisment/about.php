<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Realistic</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
?>
<div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
    <p><b><font size="+1"><strong>Book Classified & Display Advertisements for Indian Newspapers Instantly!</strong></font></b></p><p></p>
    <p align="justify"> Company Name is the easiest way to book Classified & Display Advertisements for Times of India, Hindustan Times, 
    Hindu, Mid-Day, ABP & all other leading newspaper publications! Now book Matrimonial, Property, Recruitment Newspaper Ads at lowest rates. </p>
      <div class="clear"></div>
    </div>

  <!-- ####################################################################################################### -->
    <div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
    <p><strong>Company Overview</strong>    </p>
    <p></p>
    <p>Company Name is India&#146;s simplest classified booking service! Through   our service you can book classified Ads for all leading Indian   Newspapers &#150; at no extra charges!.</p>
    <p>We are fully accredited by the Indian Newspaper Society   (I.N.S.) - the primary governing body for all media publications. We   enjoy Full Accreditation recognition from the I.N.S. - an honour only   allocated to select few advertising agencies across India. Further, we   are the only fully accredited I.N.S. Agency which specializes in   accepting classified Ad bookings from the internet. </p>
    <p>You can book your Newspaper Ad instantly for any category   such as Matrimonial, Property, Recruitment, Automobile, Travel etc. We   accept both online and offline payments for advertisement bookings.   Online payment options include Credit/Debit Cards &amp; Net Banking (All   Indian Banks), and offline options include Demand Drafts and Cheques. </p>
    <p>All of this is done in 3 easy steps: Select the   Newspaper, Compose your Ad, and Confirm the Dates along with the   Payment. After-which you receive instant confirmation, that your Ad has   been booked! If you have any particular questions towards booking an Ad   please visit our Frequently Asked Questions section. </p>
    <p>If you would like to find a way to reach us, please visit our Contact Us section. </p>
    <p align="justify">&nbsp;</p>
      <div class="clear"></div>
</div>

  <!-- ####################################################################################################### -->
    
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
   
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>