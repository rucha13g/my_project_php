<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout1.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body>
<?php
include("connection.php");
include("header.php");
include("menu.php");
?>
<div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
    <p><b><font size="+1"><strong>Book Classified & Display Advertisements for Indian Newspapers Instantly!</strong></font></b></p><p></p>
    <p align="justify"> Company Name is the easiest way to book Classified & Display Advertisements for Times of India, Hindustan Times, 
    Hindu, Mid-Day, ABP & all other leading newspaper publications! Now book Matrimonial, Property, Recruitment Newspaper Ads at lowest rates. </p>
      <div class="clear"></div>
    </div>

  <!-- ####################################################################################################### -->
    <div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
    
<table>
<tr>
<td width="50%">
    <h2 style="color:#666;">Contact Us</h2>
   			<div id="form_wraper">
            
            	<div class="add">
                <h3 style="color:#666;">Customer Relations Office:</h3>
                        Ground floor, Surbhi complex,<br/>
                                Sector-22,<br />
                    Near Jain Derashar<br/>
                                Gandhinagar-382022<br/><br/>

                        
               
         </div>
         </div>
         
      <div class="clear"></div>
 </td>
<td width="50%">
 <h2 style="color:#666;">Write A Comment</h2>
        <div id="respond">
          <form method="post">
            <p>
              <input type="text" name="name" id="name" value="" size="22" />
              <label for="name"><small>Name </small></label>
            </p>
            <p>
              <input type="text" name="no" id="no"  value="" size="22" />
              <label for="email"><small>Contact </small></label>
            </p>
             <p>
              <input type="text"  name="email" id="email" value="" size="22" />
              <label for="email"><small>Mail </small></label>
            </p>
            <p>
              <textarea name="comment" id="comment" cols="10" rows="10"></textarea>
              <label for="comment" style="display:none;"><small>Comment </small></label>
            </p>
            <p>
              <input name="submit" type="submit" id="submit" value="Submit Form" />
            </p>
          </form>
        </div>
        
        </td>
        </tr>
        </table>
        </div>
</div>

<?php
if(isset($_POST['submit']))
{
	$name = $_POST['name'];
	$no = $_POST['no'];
	$eid = $_POST['email'];
	$msg = $_POST['comment'];

	$sql = "insert into tbl_suggestion(name,contactno,emailid,comment)values('$name',$no,'$eid','$msg')";
	$result = mysql_query($sql);
	if($result)
		 {
			echo "<script language='javascript'>alert('inquiry successfully sent');</script>";
		 }
}

?>
  <!-- ####################################################################################################### -->
    
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
   
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>