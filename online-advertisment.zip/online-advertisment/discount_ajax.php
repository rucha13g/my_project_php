<?php
include("connection.php");
	global $rate,$rid,$per;

	$per=$_REQUEST['per'];
	
				$sql = "select  r.rate_id,r.rate_amount,d.per,c.city_name from tbl_rate r,tbl_discount d,tbl_city c where 
				 r.rate_id = $rid and r.isdeleted=0 and c.city_id = r.city_id and d.d_id = r.d_id  ";
				$result = mysql_query($sql) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					$rid = $row[0];
					$rate = $row[1];
					$per = $row[2];
										
				}


?>
   <td><strong>Discount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong> 
   <input type="text" name="per" id="per"  onchange="ajax_discount(this.value)" style="width:155px;" readonly value="<?php if(isset($_SERVER['PHP_SELF'])) echo $per ."%";?>" >
</td>
