<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>

</head>
<body>
<?php
include("header.php");
include("login-box.php");

include("user_menu.php");
include("connection.php");
 session_start();
 $unm = $_SESSION['user'];   
include("session_out.php");

?>
<?php 
      if(isset($_POST['submit']))
      {
		   if($_POST['submit'] == 0)
   {
      $opd=$_POST['opd'];
      $npd=$_POST['npd'];
      $cpd=$_POST['cpd'];   
	  if($npd == $cpd)
      {  
      $sql="update tbl_login set password='$cpd' where username='$unm';";
      $result = mysql_query($sql);
	  
	    $sql="update tbl_user set password='$cpd' where emailid='$unm';";
      $result1 = mysql_query($sql);
	  if($result || $result1)
	  {	
	  echo "<script language = 'javascript'> alert('password successfully updated');</script>";
	      		echo "<script language = 'javascript'> window.location.href='change_pd.php';</script>";

       }  
   }
   }

	  	  
	  }
       
      ?>
<div class="container">
   <div id="respond">

<form method="post">
       <table align="center">
       <tr>
       <td>Email Id</td>
       <td><input type="text" id="unm" name="unm" readonly="readonly" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $unm;}														
																		 ?>"/></td>
       </tr>
       <tr>
       <td>Old Password</td>
       <td><input type="password" id="opd" name="opd" /></td>
       </tr>
       <tr>
       <td>New Password</td>
       <td><input type="password" id="npd" name="npd" /></td>
       </tr>
       <tr>
       <td>Confirm Password</td>
       <td><input type="password" id="cpd" name="cpd" /></td>
       </tr>
       </table>
       <table align="center">
       <tr>
       <td><button type="submit" id="submit" name="submit" value="0" >Save Password</button></td>
       </tr>            
       </table>   
</form>    
</div>
</div>
<?php
include("footer.php");

?>
</body>
</html>