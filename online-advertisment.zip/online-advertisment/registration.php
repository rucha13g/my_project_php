<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>

</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
include("connection.php");

?>
  <div class="container">

 <div id="respond">
<form method="post">
<table align="center">
<tr>
<td>Name</td>
<td><input type="text" id="nm" name="nm" required="required" /></td>
</tr>
<tr>
<td>Contact No</td>
<td><input type="text" id="no" name="no" maxlength="10" required="required"/></td>
</tr>
<tr>
<td>Email Id </td>
<td><input type="text" id="unm" name="unm" required="required"/></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" id="pd" name="pd" required="required" maxlength="8"/></td>
</tr>
</table>
<table align="center">
<tr>
<td ><button type="submit" id="submit" name="submit" value="0" /> <font color="#663333">Registration</font></td>
</tr>
</table>

</form>

<?php
if(isset($_POST['submit']))
{
	$nm = $_POST['nm'];
	$no = $_POST['no'];
	$unm = $_POST['unm'];
	$pd = $_POST['pd'];

	$user = 'user';

$sql = "insert into tbl_user(name,contactno,emailid,password) 
values('$nm',$no,'$unm','$pd')";
$result = mysql_query($sql) or die(mysql_error());

$sql = "insert into tbl_login(username,password,type) 
values('$unm','$pd','$user')";
$result1 = mysql_query($sql) or die(mysql_error());

 if($result || $result1)
	 {
		echo "<script language = 'javascript'> alert('insertion successfull');</script>";
	 }
}

?>
</div>
</div>
<?php
include("footer.php");

?>
</body>
</html>