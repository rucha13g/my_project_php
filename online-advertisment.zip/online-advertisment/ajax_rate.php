<?php
ob_start();
include("connection.php");
	global $rate,$rid,$per,$did;

	$rid=$_REQUEST['rate'];
	
				$sql = "select  r.rate_id,r.rate_amount,d.per,c.city_name,r.d_id from tbl_rate r,tbl_discount d,tbl_city c where 
				 r.rate_id = $rid and r.isdeleted=0 and c.city_id = r.city_id and d.d_id = r.d_id  ";
				$result = mysql_query($sql) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					$rid = $row[0];
					$rate = $row[1];
					$per = $row[2];
					$did = $row[4];

				}
				session_start();
			    $_SESSION['rate'] = $rid;
				$_SESSION['per'] = $did;
//echo $rid.$did;
?>

 <td><strong>Rate  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong> 
   <input type="text" name="rate" id="rate"  onchange="ajax_rate(this.value)" style="width:155px;" readonly="readonly" value="<?php if(isset($_SERVER['PHP_SELF'])) echo $rate; ?>">
   <br/>
   <strong>Discount  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;</strong> 
    <input type="text" name="per" id="per"  onchange="ajax_rate(this.value)" style="width:155px;" readonly value="<?php if(isset($_SERVER['PHP_SELF'])) echo $per ."%";?>" >
   </td>