<?php
error_reporting(0);

include("connection.php");
global $unm1;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body id="top">
<div class="wrapper">
       <div class="fl_right" style="margin-right:240px;margin-top:-13px;">
      <form action="#" method="post">
        <fieldset>
        <table>
        
        <tr>
        <?php
					session_start();
					$unm1 = $_SESSION['user']; 
					if($unm1 == NULL)
					{
						echo "<td><font color='#FF0000'><a href='user_login.php'><b>User LogIn</b></a></font>&nbsp;&nbsp;  |&nbsp;&nbsp;   <a href='login.php'><b>Admin LogIn</b></a></font></td>";
					}
					else
					{
						echo "<td><font color='#993333'>Welcome <b>$unm1</b></font><td><td><font color='#CCCCCC'>|</font></td><td><font color='#FF0000'><a href='logout.php'><b>Logout</b></a></font></td>" ;
						
					}
				?>
        </tr> 
        </table>
        </fieldset>
      </form>
    </div>
    <br class="clear" />
</div>


</body>
</html>