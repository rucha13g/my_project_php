<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");

include("menu.php");
include("slider.php");
include("connection.php");
global $amount,$tid,$uid; 

 session_start();
  $cid1 =  $_SESSION['catid']  ;

if(isset($_SERVER['PHP_SELF']))
{
	 	$sql = "select user_id from tbl_user where emailid = '$unm' and isdeleted = 0";
    	 $result = mysql_query($sql);
		 while($r = mysql_fetch_array($result))
		 {
		 $uid = $r[0];
		 }
		 
			 $sql = "SELECT * FROM tbl_txt_ad WHERE isdeleted =0 and c_id = $cid1 ORDER BY txt_ad_id DESC LIMIT 1 ";
    	 $result = mysql_query($sql);
		 while($r = mysql_fetch_array($result))
		 {
			 $tid = $r[0];
			 
		 }
		 
		 $sql1 = "select r.rate_amount from tbl_txt_ad t,tbl_rate r where t.isdeleted= 0 and r.rate_id = t.rate_id and txt_ad_id = $tid";
    	 $result1 = mysql_query($sql1) or die(mysql_error());
		 while($r1 = mysql_fetch_array($result1))
		 {
  $amount = $r1[0];
		 }
}
?>
<div class="wrapper">
  <div class="container">
   <form method="post" enctype="multipart/form-data">

<table align="center">
<tr>
<td> <strong><font size="+1">We Accept</font></strong></td>
</tr>
<tr>
<td><img src="images/card.png" width="250px" height="50px" /></td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="Credit Cards"/>Credit Cards/Debit Cards (Master Card/Visa)</td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="Net Banking" />Net Banking(We support all major Indian Banks.)</td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="Cash collection from Home"/>Cash collection from Home( Pay for your Ad in cash from home. Available for select cities.</td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="Cheque"/>Cheque / NEFT transefer /Cash Deposite(Make your payment via NEFT /Cheque / Cash deposite in our ICICI Bank Account from any location.) </td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="Diners Club Cards"/>Diners Club Cards / PayMate</td>
</tr>
<tr>
<td><input type="radio" id="pt" name="pt" value="iCash Card" required="required"/>iCash Card</td>
</tr>
</table>
<br/>

<table align="center">
<tr>
<td>Amount </td>
<td><input type="text" id="amount" name="amount"   readonly="readonly" value="<?php 
													if(isset($_SERVER['PHP_SELF']))
														{echo $amount;}												
																		 ?>"/></td>
</tr>
<tr>
<td>Card No</td>
<td><input type="text" id="cno" name="cno" required="required" /></td>
</tr>

<tr>
<td>Name On Card</td>
<td><input type="text" id="cardnm" name="cardnm" required="required" /></td>
</tr>

<tr>
<td>Expiry Date</td>
<td><input type="text" id="edt" name="edt"  required="required"/></td>
</tr>

<tr>
<td>CVV/CVC No.</td>
<td><input type="text" id="cvv" name="cvv" required="required"/></td>
</tr>

</table>
<!--<table align="center">
<tr>
<td><button type="submit" id="submit" name="submit" value="0" />Pay</button>	</td>
</tr>
</table>-->
<br/><br/>

<table align="left">
<tr>
<td style="padding-left:40px;"> <strong><font size="+1">Enter Details</font></strong></td>
</tr>
</table>
<br/>
<br/>

<table align="center">
<tr>

<td>
	<table>
    <tr>
<td>Name</td>
<td><input type="text" id="nm" name="nm"  /></td>
</tr>
<tr>
<td>Contact No</td>
<td><input type="text" id="no" name="no" maxlength="10" /></td>
</tr>
<tr>
<td>Email Id </td>
<td><input type="text" id="unm1" name="unm1" /></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" id="pd1" name="pd1"  maxlength="8"/></td>
</tr>
<tr>
<td ><button type="submit" id="submit" name="submit" value="0" /> <font color="#663333">Registration</font></td>
</tr>
</table>
</td>


<td>
<img src="images/or_icon.gif" style="padding-left:40px;padding-right:40px;" />
</td>


<td>
	<table>
    <tr>
    <td>User Name</td>
    <td><input type="text" id="unm" name="unm" onchange="validEmail(this.event);"/></td>
    </tr>
    <tr>
    <td>Password</td>
    <td><input type="password" id="pd" name="pd" /></td>
    </tr>
    <tr>
    <td><button type="submit" id="submit" name="submit" value="1" />Log In</button></td>
    </tr>
    </table>
</td>

</tr>
</table>

</form>
<!--resiter-->
<?php
if(isset($_POST['submit']))
{
	if($_POST['submit'] == 0)
	{
	$nm = $_POST['nm'];
	$no = $_POST['no'];
	$unm1 = $_POST['unm1'];
	$pd1 = $_POST['pd1'];

	$user = 'user';

$sql = "insert into tbl_user(name,contactno,emailid,password) 
values('$nm',$no,'$unm1','$pd1') ";
$result = mysql_query($sql) or die(mysql_error());

$sql = "insert into tbl_login(username,password,type) 
values('$unm1','$pd1','$user')";
$result1 = mysql_query($sql) or die(mysql_error());

 if($result || $result1)
	 {
		echo "<script language = 'javascript'> alert('insertion successfull');</script>";
	 }
}}

?>
<!-- code of login-->
<?php 


if(isset($_POST['submit']))
{
    if($_POST['submit'] == 1)
    {
	$unm = trim($_POST['unm']);
	$pd = trim($_POST['pd']);
	
	$pt = trim($_POST['pt']);
	//$tid = trim($_POST['tid']);
	$dt = date("d-m-Y");
	//$amount = trim($_POST['amount']);
	
      		
	
	  	 $sql = "select * from tbl_login where username = '$unm' and password = '$pd' and isdeleted = 0";
    	 $result2 = mysql_query($sql);
         $count = mysql_num_rows($result2);           	 
    	 if($count >= 1)
          	 {
			 while($row = mysql_fetch_array($result2))
			 {
				 
				 $type = $row[3];
			 }
            $_SESSION['user'] = $unm;
			 }
			$sql = "insert into tbl_payment(txt_ad_id,user_id,payment_date,payment_type,payment_amount)values('$tid',$uid,'$dt','$pt','$amount')";
			$result1 = mysql_query($sql) or die(mysql_error());
			 if($result2 || $result1)
					 {
						echo "<script language = 'javascript'> window.location.href='user_home.php';</script>";

					 }

 	 }

 	 }
	?>



 </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
  <table align="center">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
     <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
       <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>
      <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
    </table>
 
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->










<?php
include("footer.php");

?>
</body>
</html>