<?php
ob_start();
error_reporting(0);
session_start();
$cid1 = $_SESSION['catid'];
echo $cid1;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
include("connection.php");

?>
  <!-- ####################################################################################################### -->
    <div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
<form method="post" enctype="multipart/form-data">

<table align="center">
<tr>
<td width="25%">Header Color</td>
<td>
<button type="button"  style="background-color:#F00;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.background='#F00'"></button>
<button type="button" style="background-color:#FF3;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.background='#FF3'"></button>
<button type="button"  style="background-color:#F9C;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.background='#F9C'"></button>
<button type="button" style="background-color:#6FF;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.background='#6FF'"></button>
<button type="button"  style="background-color:#F93;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.background='#F93'"></button>
<button type="button" style="background-color:#999;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.background='#999'"></button>
<button type="button" style="background-color:#006;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.background='#006'"></button>
</td>
</tr>

<tr>
<td width="25%">Font Color</td>
<td >
<button type="button" <button type="button"  style="background-color:#F00;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.color='#F00'"></button>
<button type="button" style="background-color:#FF3;width:20px;height:20px;border-color:#666666;border:ridge;"onclick="document.getElementById('h').style.color='#FF3'"></button>
<button type="button"  style="background-color:#F9C;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.color='#F9C'"></button>
<button type="button" style="background-color:#6FF;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.color='#6FF'"></button>
<button type="button"  style="background-color:#F93;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('h').style.color='#F93'"></button>
<button type="button" style="background-color:#999;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.color='#999'"></button>
<button type="button" style="background-color:#006;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('h').style.color='#006'"></button>
</td>
</tr>

<tr>
<td width="25%"></td>
<!--<td width="60%"><img src="images/bold.gif" />&nbsp;&nbsp;<img src="images/italic.gif" />&nbsp;&nbsp;
<img src="images/underline.gif" /> Font size</td>-->
<td >
<button type="button"   onclick="document.getElementById('h').style.fontWeight='bold'">B</button>
<button type="button" onclick="document.getElementById('h').style.fontStyle='italic'">I</button>
<button type="button"  onclick="document.getElementById('h').style.textDecoration='underline'">U</button>
Font Size:
<select style="width:155px;">
<option>--Select--</option>
  					<option onclick="document.getElementById('h').style.fontSize='10px'">Small</option>
  					<option onclick="document.getElementById('h').style.fontSize='24px'">Normal</option>
  					<option onclick="document.getElementById('h').style.fontSize='36px'">Large</option>
</select>Font Face:
<select style="width:155px;">
  					<option onclick="document.getElementById('h').style.fontFamily='Comic Sans MS, cursivei'">face1</option>
                    <option onclick="document.getElementById('h').style.fontFamily='Lucida Console, Monaco, monospace'">face2</option>
  					<option onclick="document.getElementById('h').style.fontFamily='Arial Black, Gadget, sans-serif'">face3</option>
  					<option onclick="document.getElementById('h').style.fontFamily='Lucida Sans Unicode, Lucida Grande, sans-serif'">face4</option>
  					<option onclick="document.getElementById('h').style.fontFamily='MS Serif, New York, serif'">face5</option>
  					<option onclick="document.getElementById('h').style.fontFamily='Tahoma, Geneva, sans-serif'">face6</option>
  					<option onclick="document.getElementById('h').style.fontFamily='Palatino Linotype, Book Antiqua, Palatino, serif'">face7</option>
  </select>


</td>
</tr>

<tr>
<td width="25%">Specify your Heading</td>
<td ><input type="text" name="h" id="h" style="width:600px;height:40px ;border:#333333;border-collapse:collapse;border:groove;"  required="required" >
</tr>

<tr>
<td width="25%">Bakground Color</td>
<td>
<button type="button"  style="background-color:#F00;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.background='#F00'"></button>
<button type="button" style="background-color:#FF3;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.background='#FF3'"></button>
<button type="button"  style="background-color:#F9C;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.background='#F9C'"></button>
<button type="button" style="background-color:#6FF;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.background='#6FF'"></button>
<button type="button"  style="background-color:#F93;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.background='#F93'"></button>
<button type="button" style="background-color:#999;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.background='#999'"></button>
<button type="button" style="background-color:#006;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.background='#006'"></button>
</td>
</tr>

<tr>
<td width="25%">Font Color</td>
<td >
<button type="button"  style="background-color:#F00;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.color='#F00'"></button>
<button type="button" style="background-color:#FF3;width:20px;height:20px;border-color:#666666;border:ridge;"onclick="document.getElementById('detail').style.color='#FF3'"></button>
<button type="button"  style="background-color:#F9C;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.color='#F9C'"></button>
<button type="button" style="background-color:#6FF;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.color='#6FF'"></button>
<button type="button"  style="background-color:#F93;width:20px;height:20px;border-color:#666666;border:ridge" onclick="document.getElementById('detail').style.color='#F93'"></button>
<button type="button" style="background-color:#999;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.color='#999'"></button>
<button type="button" style="background-color:#006;width:20px;height:20px;border-color:#666666;border:ridge"onclick="document.getElementById('detail').style.color='#006'"></button>
</td>
</tr>

<tr>
<td width="25%"></td>
<!--<td width="60%"><img src="images/bold.gif" />&nbsp;&nbsp;<img src="images/italic.gif" />&nbsp;&nbsp;
<img src="images/underline.gif" /> Font size</td>-->
<td >
<button type="button"   onclick="document.getElementById('detail').style.fontWeight='bold'">B</button>
<button type="button" onclick="document.getElementById('detail').style.fontStyle='italic'">I</button>
<button type="button"  onclick="document.getElementById('detail').style.textDecoration='underline'">U</button>
Font Size:
<select style="width:155px;">
<option>--Select--</option>
  					<option onclick="document.getElementById('detail').style.fontSize='10px'">Small</option>
  					<option onclick="document.getElementById('detail').style.fontSize='24px'">Normal</option>
  					<option onclick="document.getElementById('detail').style.fontSize='36px'">Large</option>
</select>
Font Face:
<select style="width:155px;">
  					<option onclick="document.getElementById('detail').style.fontFamily='Comic Sans MS, cursivei'">face1</option>
                    <option onclick="document.getElementById('detail').style.fontFamily='Lucida Console, Monaco, monospace'">face2</option>
  					<option onclick="document.getElementById('detail').style.fontFamily='Arial Black, Gadget, sans-serif'">face3</option>
  					<option onclick="document.getElementById('detail').style.fontFamily='Lucida Sans Unicode, Lucida Grande, sans-serif'">face4</option>
	<option onclick="document.getElementById('detail').style.fontFamily='MS Serif, New York, serif'">face5</option>
  					<option onclick="document.getElementById('detail').style.fontFamily='Tahoma, Geneva, sans-serif'">face6</option>
  					<option onclick="document.getElementById('detail').style.fontFamily='Palatino Linotype, Book Antiqua, Palatino, serif'">face7</option>


  
  </select>

</td>
</tr>

<tr>
<td width="25%">Specify your Advertisment</td>
<td ><input type="text" name="detail" id="detail" style="width:600px;height:40px ;border:#333333;border-collapse:collapse;border:groove;" required="required">
</tr>

<tr>
<td width="25%"></td>
<!--<td width="60%"><img src="images/bold.gif" />&nbsp;&nbsp;<img src="images/italic.gif" />&nbsp;&nbsp;
<img src="images/underline.gif" /> Font size</td>-->
<td >
Font Size:
<select style="width:155px;">
<option>--Select--</option>
  					<option onclick="document.getElementById('f').style.fontSize='10px'">Small</option>
  					<option onclick="document.getElementById('f').style.fontSize='24px'">Normal</option>
  					<option onclick="document.getElementById('f').style.fontSize='36px'">Large</option>
</select>
Font Face:
<select style="width:155px;">
  					<option onclick="document.getElementById('f').style.fontFamily='Comic Sans MS, cursivei'">face1</option>
                    <option onclick="document.getElementById('f').style.fontFamily='Lucida Console, Monaco, monospace'">face2</option>
  					<option onclick="document.getElementById('f').style.fontFamily='Arial Black, Gadget, sans-serif'">face3</option>
  					<option onclick="document.getElementById('f').style.fontFamily='Lucida Sans Unicode, Lucida Grande, sans-serif'">face4</option>
	<option onclick="document.getElementById('f').style.fontFamily='MS Serif, New York, serif'">face5</option>
  					<option onclick="document.getElementById('f').style.fontFamily='Tahoma, Geneva, sans-serif'">face6</option>
  					<option onclick="document.getElementById('f').style.fontFamily='Palatino Linotype, Book Antiqua, Palatino, serif'">face7</option>


  
  </select>
  </td>
</tr>

<tr>
<td width="25%">Specify Footer</td>
<td ><input type="text" name="f" id="f" style="width:600px;height:40px ;border:#333333;border-collapse:collapse;border:groove;" required="required" >

<td width="75%"></td>

</tr>

<tr>
<td width="25%">Display Date</td>
<td width="75%"><input type="text" id="dt" name="dt" style="height:40px ;border:#333333;border-collapse:collapse;border:groove;" required="required"/></td>
</tr>
</table>
<table align="center">
<tr>
<td><input type="submit" id="submit" name="submit" value="Next Step"  /></td>
</tr>
</table>
</form>

      <p>&nbsp;</p>
      <div class="clear"></div>
    
</div>
<?php
global $tid;
	
			
if(isset($_POST['submit']))
{

	$header = trim($_POST['h']);
	$detail = trim($_POST['detail']);
    $f = trim($_POST['f']);
      $date = date("d-m-Y");
      $dt = trim($_POST['dt']); 

 $sql = "SELECT * FROM tbl_txt_ad WHERE isdeleted =0 and c_id = '$cid1' ORDER BY `txt_ad_id` DESC LIMIT 1 '";
    	 $result = mysql_query($sql);
		 while($r = mysql_fetch_array($result))
		 {
			 $tid = $r[0];
		 }


 	 $sql = "update tbl_txt_ad set  ad_heading = '$header',txt_ad_description = '$detail' , ad_footer = '$f' , ad_book_date = '$date' , ad_display_date = '$dt'
	   where isdeleted = 0 and c_id = '$cid1' and txt_ad_id = '$tid'";
	 $result = mysql_query($sql) or die(mysql_error());
	 if($result)
	 {
		    		echo "<script language = 'javascript'>window.location.href='payment.php';</script>";
	 }
	
}
?>

    
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
  
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>