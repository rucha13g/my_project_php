<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Realistic</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
 <link href="themes/8/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/8/js-image-slider.js" type="text/javascript"></script>
    <link href="themes/8/tooltip.css" rel="stylesheet" type="text/css" />
    <script src="themes/8/tooltip.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    

</head>
<body id="top">
<div class="wrapper">
  
<div class="div1" style="margin-top:-30px;">
       </div>
    <div id="sliderFrame">
        <div id="slider">
            <a href="" target="_blank">
                <img src="images/image-slider-1.jpg" alt="#cap1" />
            </a>
            <img src="images/ju.jpg" alt="Lorem ipsum dolor sit amet" />
            <img src="images/xyz.jpg" alt="Pure Javascript. No jQuery. No flash." />
            <img src="images/abc.jpg" alt="#cap2" />
            <img src="images/b ,.jpg" alt="Excepteur sint occaecat cupidatat" />
                        <img src="images/bg123.jpg" alt="Excepteur sint occaecat cupidatat" />

        </div>
       
        </div>
    </div>
    </div>
    </body>
</html>