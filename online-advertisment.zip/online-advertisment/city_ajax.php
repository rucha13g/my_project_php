<?php
include("connection.php");
	
	$sid=$_REQUEST['state'];

?>


   City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <select name="city" id="city"  onchange="ajax_city(this.value)" style="width:155px;">
  
    <option >--Select--</option>
            <?php
			if(isset($_SERVER['PHP_SELF']))
			{
				$sql = "select * from tbl_city where isdeleted=0 and state_id = $sid";
				$result = mysql_query($sql) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					$sid = $r[0];
					echo "<a href=book_adv.php?ctid=$r[0]><option value = '$row[0]'>$row[1]</option></a>";
				}
	    	}
		  
?>

</select>


