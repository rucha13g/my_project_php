
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Network</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script language="javascript" type="text/javascript">

function ajax_state(st)
	{		
		var a;
		if(window.XMLHttpRequest)
		{
			a=new XMLHttpRequest;
		}
		else
		{
			a=new activexObject("microsoft.XMLHTTP");			
		}
		
		a.open("GET","city_ajax.php?state="+st,true);
		a.send();
		a.onreadystatechange= function()
		{
			if(a.readyState==4)
			{
				document.getElementById("state1").innerHTML=a.responseText;
			}
		}
	}  
	
	function ajax_city(ct)
	{		
		var a;
		if(window.XMLHttpRequest)
		{
			a=new XMLHttpRequest;
		}
		else
		{
			a=new activexObject("microsoft.XMLHTTP");			
		}		
		a.open("GET","paper_ajax.php?city="+ct,true);
		a.send();
		a.onreadystatechange= function()
		{
			if(a.readyState==4)
			{
				document.getElementById("city1").innerHTML=a.responseText;
			}
		}
	}
    
	
    </script>
</head>
<body>
<?php
include("header.php");
include("login-box.php");
include("menu.php");
include("connection.php");

?>
  <!-- ####################################################################################################### -->
    <div class="wrapper">
  <div class="container">
    <div class="whitebox" id="hpage_services">
   <strong> Free Advertisement</strong>
<form method="post" enctype="multipart/form-data">


   <div class="clear"></div>
         <div id="respond">

   <table align="center" >

<tr>
    <td>State  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;  <select name="state" id="state" onchange="ajax_state(this.value)" style="width:155px;">
  
    <option >--Select--</option>
            <?php
			if(isset($_SERVER['PHP_SELF']))
			{
				$sql = "select * from tbl_state where isdeleted=0";
				$result = mysql_query($sql) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					$sid = $r[0];
					echo "<option value = '$row[0]'>$row[1]</option>";
				}
	    	}
			?>
            </select>  
            
    </td>
    </tr>
       <tr id="state1"  >
    
    </tr>    
       <tr>
    <td>
    <div id="city1">    <select style="display:none;" name="city" id="city"  onchange="ajax_city(this.value)" style="width:155px;" required = "required">
     
     
    </select>
    </div>
    </td>
    </tr>
    <tr>
    <td>
   
    <div id="paper1">    <select  style="display:none;" name="paper" id="paper"  style="width:155px;" onchange="ajax_paper(this.value)" required = "required" >
  
     
    </select>
    </div>
    </td>
    </tr>
    




<?php
if(isset($_FILES['image0']))
{
    $file_name0 = $_FILES['image0']['name'];
    $file_tmp = $_FILES['image0']['tmp_name'];
    $file_size = $_FILES['image0']['size'];
   // echo $file_size;
	
    if($_FILES['image0']['size'] > 10485760)
    {
        echo "<br><br>Photo size is greater";
        
    }
    else
    {
        if(move_uploaded_file($file_tmp,'upload/'.$file_name0))
        {
			
//$sql = "insert into tbl_brand brand_logo values('$file_name0')";
//$result = mysql_query($sql);
          echo "<br><br>logo uploaded";
           //header('Location: http://localhost/rucha/upload/'. $file_name0); 
        }
    }
}
?>


                      
                       
<tr>
<td width="20%">Upload Image</td>
<td><input type="file" name="image0" id="image0" required="required"/></td>
</tr>

<tr>
<td width="20%">Display Date</td>
<td width="80%"><input type="text" id="dt" name="dt" style="height:40px ;border:#333333;border-collapse:collapse;border:groove;" required="required"/></td>
</tr>
</table>
<table align="left">
<tr>
<td><input type="submit" id="submit" name="submit" value="Next Step"  /></td>
</tr>
</table>
</div>

</form>

      <p>&nbsp;</p>
      <div class="clear"></div>
    
</div>
<?php
	
			
if(isset($_POST['submit']))
{
	
	$state = trim($_POST['state']);
	$city = trim($_POST['city']);
    $paper = trim($_POST['paper']);
	  $date = date("d-m-Y");
      $dt = trim($_POST['dt']); 
		$img = trim($_FILES['image0']['name']);

    
	
 	 $sql = "insert into tbl_txt_ad(state_id,city_id,paper_id,ad_img,ad_book_date,ad_display_date) values ('$state','$city','$paper','$img','$date','$dt')";
	 $result = mysql_query($sql) or die(mysql_error());
	  if($result)
	 {
		 
		    		echo "<script language = 'javascript'>window.location.href='login.php';</script>";
	 }
	
	 

  

	
}
?>

    
<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="footer">
    <div class="latestgallery">
      <h2>Book Advertisement For</h2>
      <ul>
        <li><a href="#"><img src="images/paper_logo/logo_1.gif" width="160" height="80"  /></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/deccon_herd.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/dna.gif" width="160" height="80" /></a></li>
         

         
         
        <li><a href="#"><img src="images/paper_logo/gujarat.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/hindustan_times.gif"  width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_2.gif" width="160" height="80" /></a></li>
         

        <li><a href="#"><img src="images/paper_logo/logo_3.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_4.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_5.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_6.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_7.gif" width="160" height="80"/></a></li>


        <li><a href="#"><img src="images/paper_logo/logo_9.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_10.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_11.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_14.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_15.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_16.gif" width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_17.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_18.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_21.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_22.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_23.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_24.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_26.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_27.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_28.gif" width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_30.gif"width="160" height="80"/></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_31.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_33.gif"width="160" height="80" /></a></li>
        <li><a href="#"><img src="images/paper_logo/logo_32.gif" width="160" height="80"/></a></li>
           <li class="last"><a href="#"><img src="images/paper_logo/many_more.gif" width="160" height="80"/></a></li>
  
</ul>
    </div>
  
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->




<?php
include("footer.php");

?>
</body>
</html>